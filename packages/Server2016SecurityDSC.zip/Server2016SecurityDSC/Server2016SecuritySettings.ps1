﻿Configuration Server2016SecuritySettings
{
	Import-DSCResource -ModuleName 'PSDesiredStateConfiguration'
	Import-DSCResource -ModuleName 'AuditPolicyDSC'
	Import-DSCResource -ModuleName 'SecurityPolicyDSC'
	Node localhost
	{
	 	AuditPolicySubcategory 'Audit Logon (Success) - Inclusion'
	 	{
	 	 	Name = 'Logon'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

 	 	AuditPolicySubcategory 'Audit Logon (Failure) - Inclusion'
	 	{
	 	 	Name = 'Logon'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Failure'

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Load_and_unload_device_drivers'
	 	{
	 	 	Policy = 'Load_and_unload_device_drivers'
	 	 	Identity = @('*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Deny_log_on_locally'
	 	{
	 	 	Policy = 'Deny_log_on_locally'
	 	 	Identity = @('*S-1-5-32-546'
	 	 	)

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\ConsentPromptBehaviorAdmin'
	 	{
	 	 	ValueName = 'ConsentPromptBehaviorAdmin'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
	 	 	ValueData = 2

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters\MaximumPasswordAge'
	 	{
	 	 	ValueName = 'MaximumPasswordAge'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters'
	 	 	ValueData = 15

	 	}

	 	SecurityOption 'SecuritySetting(INF): NewGuestName'
	 	{
	 	 	Accounts_Rename_guest_account = 'dos-guest'
	 	 	Name = 'Accounts_Rename_guest_account'

	 	}

	 	SecurityOption 'SecuritySetting(INF): EnableGuestAccount'
	 	{
	 	 	Accounts_Guest_account_status = 'Disabled'
	 	 	Name = 'Accounts_Guest_account_status'

	 	}

	 	AccountPolicy 'SecuritySetting(INF): PasswordComplexity'
	 	{
	 	 	Name = 'Password_must_meet_complexity_requirements'
	 	 	Password_must_meet_complexity_requirements = 'Enabled'

	 	}

	}
}