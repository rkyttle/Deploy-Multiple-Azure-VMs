﻿Configuration securevm
{

	Import-DSCResource -ModuleName 'PSDesiredStateConfiguration'
	Import-DSCResource -ModuleName 'AuditPolicyDSC'
	Import-DSCResource -ModuleName 'SecurityPolicyDSC'
	Import-DSCResource -ModuleName 'BaselineManagement'
	# Module Not Found: Import-DSCResource -ModuleName 'xSMBShare'
	# Module Not Found: Import-DSCResource -ModuleName 'DSCR_PowerPlan'
	# Module Not Found: Import-DSCResource -ModuleName 'xScheduledTask'
	# Module Not Found: Import-DSCResource -ModuleName 'Carbon'
	# Module Not Found: Import-DSCResource -ModuleName 'PrinterManagement'
	# Module Not Found: Import-DSCResource -ModuleName 'rsInternationalSettings'
	Node localhost
	{
	 	Registry 'Registry(POL): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\CredUI\EnumerateAdministrators'
	 	{
	 	 	ValueName = 'EnumerateAdministrators'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\CredUI'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\NoDriveTypeAutoRun'
	 	{
	 	 	ValueName = 'NoDriveTypeAutoRun'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\NoInternetOpenWith'
	 	{
	 	 	ValueName = 'NoInternetOpenWith'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\PreXPSP2ShellProtocolBehavior'
	 	{
	 	 	ValueName = 'PreXPSP2ShellProtocolBehavior'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\NoAutorun'
	 	{
	 	 	ValueName = 'NoAutorun'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Servicing\LocalSourcePath'
	 	{
	 	 	ValueName = 'LocalSourcePath'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Servicing'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Servicing\UseWindowsUpdate'
	 	{
	 	 	ValueName = 'UseWindowsUpdate'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Servicing'

	 	}

	 	Registry 'DEL_\Software\Microsoft\Windows\CurrentVersion\Policies\Servicing\RepairContentServerSource'
	 	{
	 	 	ValueName = 'RepairContentServerSource'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Servicing'
	 	 	Ensure = 'Absent'

	 	}

	 	Registry 'DEL_\Software\Microsoft\Windows\CurrentVersion\Policies\System\DisableBkGndGroupPolicy'
	 	{
	 	 	ValueName = 'DisableBkGndGroupPolicy'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
	 	 	Ensure = 'Absent'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\LogonType'
	 	{
	 	 	ValueName = 'LogonType'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\MSAOptional'
	 	{
	 	 	ValueName = 'MSAOptional'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\DisableAutomaticRestartSignOn'
	 	{
	 	 	ValueName = 'DisableAutomaticRestartSignOn'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\LocalAccountTokenFilterPolicy'
	 	{
	 	 	ValueName = 'LocalAccountTokenFilterPolicy'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\Audit\ProcessCreationIncludeCmdLine_Enabled'
	 	{
	 	 	ValueName = 'ProcessCreationIncludeCmdLine_Enabled'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\Audit'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon\AutoAdminLogon'
	 	{
	 	 	ValueName = 'AutoAdminLogon'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon\ScreenSaverGracePeriod'
	 	{
	 	 	ValueName = 'ScreenSaverGracePeriod'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Biometrics\Enabled'
	 	{
	 	 	ValueName = 'Enabled'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Biometrics'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Control Panel\International\BlockUserInputMethodsForSignIn'
	 	{
	 	 	ValueName = 'BlockUserInputMethodsForSignIn'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Control Panel\International'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\EventViewer\MicrosoftEventVwrDisableLinks'
	 	{
	 	 	ValueName = 'MicrosoftEventVwrDisableLinks'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\EventViewer'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Internet Explorer\Feeds\DisableEnclosureDownload'
	 	{
	 	 	ValueName = 'DisableEnclosureDownload'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Internet Explorer\Feeds'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Internet Explorer\Feeds\AllowBasicAuthInClear'
	 	{
	 	 	ValueName = 'AllowBasicAuthInClear'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Internet Explorer\Feeds'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Peernet\Disabled'
	 	{
	 	 	ValueName = 'Disabled'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Peernet'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Power\PowerSettings\0e796bdb-100d-47d6-a2d5-f7d2daa51f51\DCSettingIndex'
	 	{
	 	 	ValueName = 'DCSettingIndex'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Power\PowerSettings\0e796bdb-100d-47d6-a2d5-f7d2daa51f51'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Power\PowerSettings\0e796bdb-100d-47d6-a2d5-f7d2daa51f51\ACSettingIndex'
	 	{
	 	 	ValueName = 'ACSettingIndex'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Power\PowerSettings\0e796bdb-100d-47d6-a2d5-f7d2daa51f51'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\SQMClient\Windows\CEIPEnable'
	 	{
	 	 	ValueName = 'CEIPEnable'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\SQMClient\Windows'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\AppCompat\DisableInventory'
	 	{
	 	 	ValueName = 'DisableInventory'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\AppCompat'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\AppCompat\DisablePcaUI'
	 	{
	 	 	ValueName = 'DisablePcaUI'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\AppCompat'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\Appx\AllowAllTrustedApps'
	 	{
	 	 	ValueName = 'AllowAllTrustedApps'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\Appx'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\CredUI\DisablePasswordReveal'
	 	{
	 	 	ValueName = 'DisablePasswordReveal'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\CredUI'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\Device Metadata\PreventDeviceMetadataFromNetwork'
	 	{
	 	 	ValueName = 'PreventDeviceMetadataFromNetwork'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\Device Metadata'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\DeviceInstall\Settings\AllowRemoteRPC'
	 	{
	 	 	ValueName = 'AllowRemoteRPC'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\DeviceInstall\Settings'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\DeviceInstall\Settings\DisableSystemRestore'
	 	{
	 	 	ValueName = 'DisableSystemRestore'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\DeviceInstall\Settings'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\DeviceInstall\Settings\DisableSendGenericDriverNotFoundToWER'
	 	{
	 	 	ValueName = 'DisableSendGenericDriverNotFoundToWER'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\DeviceInstall\Settings'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\DeviceInstall\Settings\DisableSendRequestAdditionalSoftwareToWER'
	 	{
	 	 	ValueName = 'DisableSendRequestAdditionalSoftwareToWER'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\DeviceInstall\Settings'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\DriverSearching\DontSearchWindowsUpdate'
	 	{
	 	 	ValueName = 'DontSearchWindowsUpdate'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\DriverSearching'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\DriverSearching\DontPromptForWindowsUpdate'
	 	{
	 	 	ValueName = 'DontPromptForWindowsUpdate'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\DriverSearching'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\DriverSearching\SearchOrderConfig'
	 	{
	 	 	ValueName = 'SearchOrderConfig'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\DriverSearching'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\DriverSearching\DriverServerSelection'
	 	{
	 	 	ValueName = 'DriverServerSelection'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\DriverSearching'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\EventLog\Application\MaxSize'
	 	{
	 	 	ValueName = 'MaxSize'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\EventLog\Application'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\EventLog\Security\MaxSize'
	 	{
	 	 	ValueName = 'MaxSize'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\EventLog\Security'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\EventLog\Setup\MaxSize'
	 	{
	 	 	ValueName = 'MaxSize'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\EventLog\Setup'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\EventLog\System\MaxSize'
	 	{
	 	 	ValueName = 'MaxSize'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\EventLog\System'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\Explorer\NoHeapTerminationOnCorruption'
	 	{
	 	 	ValueName = 'NoHeapTerminationOnCorruption'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\Explorer'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\Explorer\NoAutoplayfornonVolume'
	 	{
	 	 	ValueName = 'NoAutoplayfornonVolume'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\Explorer'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\Explorer\NoDataExecutionPrevention'
	 	{
	 	 	ValueName = 'NoDataExecutionPrevention'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\Explorer'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\Explorer\NoUseStoreOpenWith'
	 	{
	 	 	ValueName = 'NoUseStoreOpenWith'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\Explorer'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\Group Policy\{35378EAC-683F-11D2-A89A-00C04FBBCFA2}\NoBackgroundPolicy'
	 	{
	 	 	ValueName = 'NoBackgroundPolicy'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\Group Policy\{35378EAC-683F-11D2-A89A-00C04FBBCFA2}'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\Group Policy\{35378EAC-683F-11D2-A89A-00C04FBBCFA2}\NoGPOListChanges'
	 	{
	 	 	ValueName = 'NoGPOListChanges'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\Group Policy\{35378EAC-683F-11D2-A89A-00C04FBBCFA2}'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\HandwritingErrorReports\PreventHandwritingErrorReports'
	 	{
	 	 	ValueName = 'PreventHandwritingErrorReports'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\HandwritingErrorReports'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\Installer\SafeForScripting'
	 	{
	 	 	ValueName = 'SafeForScripting'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\Installer'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\Installer\EnableUserControl'
	 	{
	 	 	ValueName = 'EnableUserControl'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\Installer'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\Installer\DisableLUAPatching'
	 	{
	 	 	ValueName = 'DisableLUAPatching'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\Installer'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\Installer\AlwaysInstallElevated'
	 	{
	 	 	ValueName = 'AlwaysInstallElevated'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\Installer'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\LLTD\EnableLLTDIO'
	 	{
	 	 	ValueName = 'EnableLLTDIO'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\LLTD'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\LLTD\AllowLLTDIOOnDomain'
	 	{
	 	 	ValueName = 'AllowLLTDIOOnDomain'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\LLTD'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\LLTD\AllowLLTDIOOnPublicNet'
	 	{
	 	 	ValueName = 'AllowLLTDIOOnPublicNet'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\LLTD'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\LLTD\ProhibitLLTDIOOnPrivateNet'
	 	{
	 	 	ValueName = 'ProhibitLLTDIOOnPrivateNet'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\LLTD'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\LLTD\EnableRspndr'
	 	{
	 	 	ValueName = 'EnableRspndr'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\LLTD'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\LLTD\AllowRspndrOnDomain'
	 	{
	 	 	ValueName = 'AllowRspndrOnDomain'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\LLTD'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\LLTD\AllowRspndrOnPublicNet'
	 	{
	 	 	ValueName = 'AllowRspndrOnPublicNet'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\LLTD'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\LLTD\ProhibitRspndrOnPrivateNet'
	 	{
	 	 	ValueName = 'ProhibitRspndrOnPrivateNet'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\LLTD'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\LocationAndSensors\DisableLocation'
	 	{
	 	 	ValueName = 'DisableLocation'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\LocationAndSensors'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\Network Connections\NC_AllowNetBridge_NLA'
	 	{
	 	 	ValueName = 'NC_AllowNetBridge_NLA'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\Network Connections'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\Network Connections\NC_StdDomainUserSetLocation'
	 	{
	 	 	ValueName = 'NC_StdDomainUserSetLocation'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\Network Connections'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\Personalization\NoLockScreenSlideshow'
	 	{
	 	 	ValueName = 'NoLockScreenSlideshow'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\Personalization'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\ScriptedDiagnosticsProvider\Policy\DisableQueryRemoteServer'
	 	{
	 	 	ValueName = 'DisableQueryRemoteServer'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\ScriptedDiagnosticsProvider\Policy'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\ScriptedDiagnosticsProvider\Policy\EnableQueryRemoteServer'
	 	{
	 	 	ValueName = 'EnableQueryRemoteServer'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\ScriptedDiagnosticsProvider\Policy'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\System\EnumerateLocalUsers'
	 	{
	 	 	ValueName = 'EnumerateLocalUsers'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\System'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\System\DisableLockScreenAppNotifications'
	 	{
	 	 	ValueName = 'DisableLockScreenAppNotifications'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\System'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\System\DontDisplayNetworkSelectionUI'
	 	{
	 	 	ValueName = 'DontDisplayNetworkSelectionUI'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\System'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\System\EnableSmartScreen'
	 	{
	 	 	ValueName = 'EnableSmartScreen'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\System'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\TabletPC\PreventHandwritingDataSharing'
	 	{
	 	 	ValueName = 'PreventHandwritingDataSharing'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\TabletPC'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\TCPIP\v6Transition\Force_Tunneling'
	 	{
	 	 	ValueName = 'Force_Tunneling'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\TCPIP\v6Transition'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\TCPIP\v6Transition\6to4_State'
	 	{
	 	 	ValueName = '6to4_State'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\TCPIP\v6Transition'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\TCPIP\v6Transition\ISATAP_State'
	 	{
	 	 	ValueName = 'ISATAP_State'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\TCPIP\v6Transition'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\TCPIP\v6Transition\Teredo_State'
	 	{
	 	 	ValueName = 'Teredo_State'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\TCPIP\v6Transition'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\TCPIP\v6Transition\IPHTTPS\IPHTTPSInterface\IPHTTPS_ClientUrl'
	 	{
	 	 	ValueName = 'IPHTTPS_ClientUrl'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\TCPIP\v6Transition\IPHTTPS\IPHTTPSInterface'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\TCPIP\v6Transition\IPHTTPS\IPHTTPSInterface\IPHTTPS_ClientState'
	 	{
	 	 	ValueName = 'IPHTTPS_ClientState'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\TCPIP\v6Transition\IPHTTPS\IPHTTPSInterface'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\WCN\Registrars\EnableRegistrars'
	 	{
	 	 	ValueName = 'EnableRegistrars'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\WCN\Registrars'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\WCN\Registrars\DisableUPnPRegistrar'
	 	{
	 	 	ValueName = 'DisableUPnPRegistrar'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\WCN\Registrars'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\WCN\Registrars\DisableInBand802DOT11Registrar'
	 	{
	 	 	ValueName = 'DisableInBand802DOT11Registrar'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\WCN\Registrars'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\WCN\Registrars\DisableFlashConfigRegistrar'
	 	{
	 	 	ValueName = 'DisableFlashConfigRegistrar'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\WCN\Registrars'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\WCN\Registrars\DisableWPDRegistrar'
	 	{
	 	 	ValueName = 'DisableWPDRegistrar'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\WCN\Registrars'

	 	}

	 	Registry 'DEL_\Software\policies\Microsoft\Windows\WCN\Registrars\MaxWCNDeviceNumber'
	 	{
	 	 	ValueName = 'MaxWCNDeviceNumber'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\WCN\Registrars'
	 	 	Ensure = 'Absent'

	 	}

	 	Registry 'DEL_\Software\policies\Microsoft\Windows\WCN\Registrars\HigherPrecedenceRegistrar'
	 	{
	 	 	ValueName = 'HigherPrecedenceRegistrar'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\WCN\Registrars'
	 	 	Ensure = 'Absent'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\WCN\UI\DisableWcnUi'
	 	{
	 	 	ValueName = 'DisableWcnUi'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\WCN\UI'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\WDI\{9c5a40da-b965-4fc3-8781-88dd50a6299d}\ScenarioExecutionEnabled'
	 	{
	 	 	ValueName = 'ScenarioExecutionEnabled'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\WDI\{9c5a40da-b965-4fc3-8781-88dd50a6299d}'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\WinRM\Client\AllowBasic'
	 	{
	 	 	ValueName = 'AllowBasic'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\WinRM\Client'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\WinRM\Client\AllowUnencryptedTraffic'
	 	{
	 	 	ValueName = 'AllowUnencryptedTraffic'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\WinRM\Client'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\WinRM\Client\AllowDigest'
	 	{
	 	 	ValueName = 'AllowDigest'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\WinRM\Client'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\WinRM\Service\AllowBasic'
	 	{
	 	 	ValueName = 'AllowBasic'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\WinRM\Service'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\WinRM\Service\AllowUnencryptedTraffic'
	 	{
	 	 	ValueName = 'AllowUnencryptedTraffic'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\WinRM\Service'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows\WinRM\Service\DisableRunAs'
	 	{
	 	 	ValueName = 'DisableRunAs'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows\WinRM\Service'

	 	}

	 	Registry 'DEL_\Software\policies\Microsoft\Windows Defender\Spynet\SpynetReporting'
	 	{
	 	 	ValueName = 'SpynetReporting'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows Defender\Spynet'
	 	 	Ensure = 'Absent'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Printers\DisableHTTPPrinting'
	 	{
	 	 	ValueName = 'DisableHTTPPrinting'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Printers'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Printers\DisableWebPnPDownload'
	 	{
	 	 	ValueName = 'DisableWebPnPDownload'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Printers'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Printers\DoNotInstallCompatibleDriverFromWindowsUpdate'
	 	{
	 	 	ValueName = 'DoNotInstallCompatibleDriverFromWindowsUpdate'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Printers'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Rpc\RestrictRemoteClients'
	 	{
	 	 	ValueName = 'RestrictRemoteClients'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Rpc'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services\fAllowToGetHelp'
	 	{
	 	 	ValueName = 'fAllowToGetHelp'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'

	 	}

	 	Registry 'DEL_\Software\policies\Microsoft\Windows NT\Terminal Services\fAllowFullControl'
	 	{
	 	 	ValueName = 'fAllowFullControl'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'
	 	 	Ensure = 'Absent'

	 	}

	 	Registry 'DEL_\Software\policies\Microsoft\Windows NT\Terminal Services\MaxTicketExpiry'
	 	{
	 	 	ValueName = 'MaxTicketExpiry'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'
	 	 	Ensure = 'Absent'

	 	}

	 	Registry 'DEL_\Software\policies\Microsoft\Windows NT\Terminal Services\MaxTicketExpiryUnits'
	 	{
	 	 	ValueName = 'MaxTicketExpiryUnits'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'
	 	 	Ensure = 'Absent'

	 	}

	 	Registry 'DEL_\Software\policies\Microsoft\Windows NT\Terminal Services\fUseMailto'
	 	{
	 	 	ValueName = 'fUseMailto'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'
	 	 	Ensure = 'Absent'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services\fPromptForPassword'
	 	{
	 	 	ValueName = 'fPromptForPassword'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services\MinEncryptionLevel'
	 	{
	 	 	ValueName = 'MinEncryptionLevel'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services\PerSessionTempDir'
	 	{
	 	 	ValueName = 'PerSessionTempDir'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services\DeleteTempDirsOnExit'
	 	{
	 	 	ValueName = 'DeleteTempDirsOnExit'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services\fAllowUnsolicited'
	 	{
	 	 	ValueName = 'fAllowUnsolicited'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'

	 	}

	 	Registry 'DEL_\Software\policies\Microsoft\Windows NT\Terminal Services\fAllowUnsolicitedFullControl'
	 	{
	 	 	ValueName = 'fAllowUnsolicitedFullControl'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'
	 	 	Ensure = 'Absent'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services\fEncryptRPCTraffic'
	 	{
	 	 	ValueName = 'fEncryptRPCTraffic'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services\DisablePasswordSaving'
	 	{
	 	 	ValueName = 'DisablePasswordSaving'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services\fDisableCdm'
	 	{
	 	 	ValueName = 'fDisableCdm'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services\LoggingEnabled'
	 	{
	 	 	ValueName = 'LoggingEnabled'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services\fSingleSessionPerUser'
	 	{
	 	 	ValueName = 'fSingleSessionPerUser'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services\fDisableCcm'
	 	{
	 	 	ValueName = 'fDisableCcm'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services\fDisableLPT'
	 	{
	 	 	ValueName = 'fDisableLPT'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services\fDisablePNPRedir'
	 	{
	 	 	ValueName = 'fDisablePNPRedir'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services\fEnableSmartCard'
	 	{
	 	 	ValueName = 'fEnableSmartCard'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services\RedirectOnlyDefaultClientPrinter'
	 	{
	 	 	ValueName = 'RedirectOnlyDefaultClientPrinter'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services'

	 	}

	 	<#Registry 'DELVALS_\Software\policies\Microsoft\Windows NT\Terminal Services\RAUnsolicit'
	 	{
	 	 	ValueName = ''
	 	 	Key = 'HKLM:\Software\policies\Microsoft\Windows NT\Terminal Services\RAUnsolicit'
	 	 	Ensure = 'Present'
	 	 	Exclusive = $True

	 	}#>

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\WindowsMediaPlayer\DisableAutoUpdate'
	 	{
	 	 	ValueName = 'DisableAutoUpdate'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\WindowsMediaPlayer'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\WindowsMediaPlayer\GroupPrivacyAcceptance'
	 	{
	 	 	ValueName = 'GroupPrivacyAcceptance'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\WindowsMediaPlayer'

	 	}

	 	Registry 'Registry(POL): HKLM:\Software\policies\Microsoft\WMDRM\DisableOnline'
	 	{
	 	 	ValueName = 'DisableOnline'
	 	 	Key = 'HKLM:\Software\policies\Microsoft\WMDRM'

	 	}

	 	Registry 'Registry(POL): HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest\UseLogonCredential'
	 	{
	 	 	ValueName = 'UseLogonCredential'
	 	 	Key = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest'

	 	}

	 	Registry 'Registry(POL): HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\SafeDllSearchMode'
	 	{
	 	 	ValueName = 'SafeDllSearchMode'
	 	 	Key = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager'

	 	}

	 	Registry 'Registry(POL): HKLM:\SYSTEM\CurrentControlSet\Policies\EarlyLaunch\DriverLoadPolicy'
	 	{
	 	 	ValueName = 'DriverLoadPolicy'
	 	 	Key = 'HKLM:\SYSTEM\CurrentControlSet\Policies\EarlyLaunch'

	 	}

	 	Registry 'Registry(POL): HKLM:\SYSTEM\CurrentControlSet\Services\Eventlog\Security\WarningLevel'
	 	{
	 	 	ValueName = 'WarningLevel'
	 	 	Key = 'HKLM:\SYSTEM\CurrentControlSet\Services\Eventlog\Security'

	 	}

	 	Registry 'Registry(POL): HKLM:\SYSTEM\CurrentControlSet\Services\IPSEC\NoDefaultExempt'
	 	{
	 	 	ValueName = 'NoDefaultExempt'
	 	 	Key = 'HKLM:\SYSTEM\CurrentControlSet\Services\IPSEC'

	 	}

	 	Registry 'Registry(POL): HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters\SMB1'
	 	{
	 	 	ValueName = 'SMB1'
	 	 	Key = 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters'

	 	}

	 	Registry 'Registry(POL): HKLM:\SYSTEM\CurrentControlSet\Services\MrxSmb10\Start'
	 	{
	 	 	ValueName = 'Start'
	 	 	Key = 'HKLM:\SYSTEM\CurrentControlSet\Services\MrxSmb10'

	 	}

	 	Registry 'Registry(POL): HKLM:\SYSTEM\CurrentControlSet\Services\Netbt\Parameters\NoNameReleaseOnDemand'
	 	{
	 	 	ValueName = 'NoNameReleaseOnDemand'
	 	 	Key = 'HKLM:\SYSTEM\CurrentControlSet\Services\Netbt\Parameters'

	 	}

	 	Registry 'Registry(POL): HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\DisableIPSourceRouting'
	 	{
	 	 	ValueName = 'DisableIPSourceRouting'
	 	 	Key = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters'

	 	}

	 	Registry 'Registry(POL): HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\EnableICMPRedirect'
	 	{
	 	 	ValueName = 'EnableICMPRedirect'
	 	 	Key = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters'

	 	}

	 	Registry 'Registry(POL): HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\PerformRouterDiscovery'
	 	{
	 	 	ValueName = 'PerformRouterDiscovery'
	 	 	Key = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters'

	 	}

	 	Registry 'Registry(POL): HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\KeepAliveTime'
	 	{
	 	 	ValueName = 'KeepAliveTime'
	 	 	Key = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters'

	 	}

	 	Registry 'Registry(POL): HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\TcpMaxDataRetransmissions'
	 	{
	 	 	ValueName = 'TcpMaxDataRetransmissions'
	 	 	Key = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters'

	 	}

	 	Registry 'Registry(POL): HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\EnableIPAutoConfigurationLimits'
	 	{
	 	 	ValueName = 'EnableIPAutoConfigurationLimits'
	 	 	Key = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters'

	 	}

	 	Registry 'Registry(POL): HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters\DisableIPSourceRouting'
	 	{
	 	 	ValueName = 'DisableIPSourceRouting'
	 	 	Key = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters'

	 	}

	 	Registry 'Registry(POL): HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters\TcpMaxDataRetransmissions'
	 	{
	 	 	ValueName = 'TcpMaxDataRetransmissions'
	 	 	Key = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters'

	 	}

	 	AuditPolicySubcategory 'Audit Credential Validation (Success) - Inclusion'
	 	{
	 	 	Name = 'Credential Validation'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

 	 	AuditPolicySubcategory 'Audit Credential Validation (Failure) - Inclusion'
	 	{
	 	 	Name = 'Credential Validation'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Failure'

	 	}

	 	AuditPolicySubcategory 'Audit Computer Account Management (Success) - Inclusion'
	 	{
	 	 	Name = 'Computer Account Management'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

 	 	AuditPolicySubcategory 'Audit Computer Account Management (Failure) - Inclusion'
	 	{
	 	 	Name = 'Computer Account Management'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Failure'

	 	}

	 	AuditPolicySubcategory 'Audit Other Account Management Events (Success) - Inclusion'
	 	{
	 	 	Name = 'Other Account Management Events'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

 	 	AuditPolicySubcategory 'Audit Other Account Management Events (Failure) - Inclusion'
	 	{
	 	 	Name = 'Other Account Management Events'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Failure'

	 	}

	 	AuditPolicySubcategory 'Audit Security Group Management (Success) - Inclusion'
	 	{
	 	 	Name = 'Security Group Management'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

 	 	AuditPolicySubcategory 'Audit Security Group Management (Failure) - Inclusion'
	 	{
	 	 	Name = 'Security Group Management'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Failure'

	 	}

	 	AuditPolicySubcategory 'Audit User Account Management (Success) - Inclusion'
	 	{
	 	 	Name = 'User Account Management'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

 	 	AuditPolicySubcategory 'Audit User Account Management (Failure) - Inclusion'
	 	{
	 	 	Name = 'User Account Management'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Failure'

	 	}

	 	AuditPolicySubcategory 'Audit Process Creation - Inclusion'
	 	{
	 	 	Name = 'Process Creation'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

	 	AuditPolicySubcategory 'Audit Logoff - Inclusion'
	 	{
	 	 	Name = 'Logoff'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

	 	AuditPolicySubcategory 'Audit Logon (Success) - Inclusion'
	 	{
	 	 	Name = 'Logon'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

 	 	AuditPolicySubcategory 'Audit Logon (Failure) - Inclusion'
	 	{
	 	 	Name = 'Logon'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Failure'

	 	}

	 	AuditPolicySubcategory 'Audit Special Logon - Inclusion'
	 	{
	 	 	Name = 'Special Logon'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

	 	AuditPolicySubcategory 'Audit Removable Storage (Success) - Inclusion'
	 	{
	 	 	Name = 'Removable Storage'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

 	 	AuditPolicySubcategory 'Audit Removable Storage (Failure) - Inclusion'
	 	{
	 	 	Name = 'Removable Storage'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Failure'

	 	}

	 	AuditPolicySubcategory 'Audit Central Access Policy Staging (Success) - Inclusion'
	 	{
	 	 	Name = 'Central Policy Staging'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

 	 	AuditPolicySubcategory 'Audit Central Access Policy Staging (Failure) - Inclusion'
	 	{
	 	 	Name = 'Central Policy Staging'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Failure'

	 	}

	 	AuditPolicySubcategory 'Audit Audit Policy Change (Success) - Inclusion'
	 	{
	 	 	Name = 'Audit Policy Change'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

 	 	AuditPolicySubcategory 'Audit Audit Policy Change (Failure) - Inclusion'
	 	{
	 	 	Name = 'Audit Policy Change'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Failure'

	 	}

	 	AuditPolicySubcategory 'Audit Authentication Policy Change - Inclusion'
	 	{
	 	 	Name = 'Authentication Policy Change'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

	 	AuditPolicySubcategory 'Audit Authorization Policy Change (Success) - Inclusion'
	 	{
	 	 	Name = 'Authorization Policy Change'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

 	 	AuditPolicySubcategory 'Audit Authorization Policy Change (Failure) - Inclusion'
	 	{
	 	 	Name = 'Authorization Policy Change'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Failure'

	 	}

	 	AuditPolicySubcategory 'Audit Sensitive Privilege Use (Success) - Inclusion'
	 	{
	 	 	Name = 'Sensitive Privilege Use'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

 	 	AuditPolicySubcategory 'Audit Sensitive Privilege Use (Failure) - Inclusion'
	 	{
	 	 	Name = 'Sensitive Privilege Use'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Failure'

	 	}

	 	AuditPolicySubcategory 'Audit IPsec Driver (Success) - Inclusion'
	 	{
	 	 	Name = 'IPsec Driver'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

 	 	AuditPolicySubcategory 'Audit IPsec Driver (Failure) - Inclusion'
	 	{
	 	 	Name = 'IPsec Driver'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Failure'

	 	}

	 	AuditPolicySubcategory 'Audit Security State Change (Success) - Inclusion'
	 	{
	 	 	Name = 'Security State Change'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

 	 	AuditPolicySubcategory 'Audit Security State Change (Failure) - Inclusion'
	 	{
	 	 	Name = 'Security State Change'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Failure'

	 	}

	 	AuditPolicySubcategory 'Audit Security System Extension (Success) - Inclusion'
	 	{
	 	 	Name = 'Security System Extension'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

 	 	AuditPolicySubcategory 'Audit Security System Extension (Failure) - Inclusion'
	 	{
	 	 	Name = 'Security System Extension'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Failure'

	 	}

	 	AuditPolicySubcategory 'Audit System Integrity (Success) - Inclusion'
	 	{
	 	 	Name = 'System Integrity'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Success'

	 	}

 	 	AuditPolicySubcategory 'Audit System Integrity (Failure) - Inclusion'
	 	{
	 	 	Name = 'System Integrity'
	 	 	Ensure = 'Present'
	 	 	AuditFlag = 'Failure'

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Load_and_unload_device_drivers'
	 	{
	 	 	Policy = 'Load_and_unload_device_drivers'
	 	 	Identity = @('*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Impersonate_a_client_after_authentication'
	 	{
	 	 	Policy = 'Impersonate_a_client_after_authentication'
	 	 	Identity = @('*S-1-5-6', '*S-1-5-20', '*S-1-5-19', '*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Take_ownership_of_files_or_other_objects'
	 	{
	 	 	Policy = 'Take_ownership_of_files_or_other_objects'
	 	 	Identity = @('*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Deny_log_on_locally'
	 	{
	 	 	Policy = 'Deny_log_on_locally'
	 	 	Identity = @('*S-1-5-32-546', 'ADD YOUR ENTERPRISE ADMINS', 'ADD YOUR DOMAIN ADMINS'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Deny_log_on_as_a_batch_job'
	 	{
	 	 	Policy = 'Deny_log_on_as_a_batch_job'
	 	 	Identity = @('*S-1-5-32-546', 'ADD YOUR ENTERPRISE ADMINS', 'ADD YOUR DOMAIN ADMINS'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Allow_log_on_through_Remote_Desktop_Services'
	 	{
	 	 	Policy = 'Allow_log_on_through_Remote_Desktop_Services'
	 	 	Identity = @('*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Modify_an_object_label'
	 	{
	 	 	Policy = 'Modify_an_object_label'
	 	 	Identity = @(''
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Create_symbolic_links'
	 	{
	 	 	Policy = 'Create_symbolic_links'
	 	 	Identity = @('*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Change_the_system_time'
	 	{
	 	 	Policy = 'Change_the_system_time'
	 	 	Identity = @('*S-1-5-19', '*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Debug_programs'
	 	{
	 	 	Policy = 'Debug_programs'
	 	 	Identity = @('*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Deny_log_on_through_Remote_Desktop_Services'
	 	{
	 	 	Policy = 'Deny_log_on_through_Remote_Desktop_Services'
	 	 	Identity = @('*S-1-5-113', '*S-1-5-32-546', 'ADD YOUR ENTERPRISE ADMINS', 'ADD YOUR DOMAIN ADMINS'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Lock_pages_in_memory'
	 	{
	 	 	Policy = 'Lock_pages_in_memory'
	 	 	Identity = @(''
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Increase_scheduling_priority'
	 	{
	 	 	Policy = 'Increase_scheduling_priority'
	 	 	Identity = @('*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Shut_down_the_system'
	 	{
	 	 	Policy = 'Shut_down_the_system'
	 	 	Identity = @('*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Change_the_time_zone'
	 	{
	 	 	Policy = 'Change_the_time_zone'
	 	 	Identity = @('*S-1-5-19', '*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Modify_firmware_environment_values'
	 	{
	 	 	Policy = 'Modify_firmware_environment_values'
	 	 	Identity = @('*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Profile_single_process'
	 	{
	 	 	Policy = 'Profile_single_process'
	 	 	Identity = @('*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Replace_a_process_level_token'
	 	{
	 	 	Policy = 'Replace_a_process_level_token'
	 	 	Identity = @('*S-1-5-20', '*S-1-5-19'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Allow_log_on_locally'
	 	{
	 	 	Policy = 'Allow_log_on_locally'
	 	 	Identity = @('*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Create_a_pagefile'
	 	{
	 	 	Policy = 'Create_a_pagefile'
	 	 	Identity = @('*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Restore_files_and_directories'
	 	{
	 	 	Policy = 'Restore_files_and_directories'
	 	 	Identity = @('*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Create_a_token_object'
	 	{
	 	 	Policy = 'Create_a_token_object'
	 	 	Identity = @(''
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Create_permanent_shared_objects'
	 	{
	 	 	Policy = 'Create_permanent_shared_objects'
	 	 	Identity = @(''
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Profile_system_performance'
	 	{
	 	 	Policy = 'Profile_system_performance'
	 	 	Identity = @('*S-1-5-80-3139157870-2983391045-3678747466-658725712-1809340420', '*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Create_global_objects'
	 	{
	 	 	Policy = 'Create_global_objects'
	 	 	Identity = @('*S-1-5-6', '*S-1-5-20', '*S-1-5-19', '*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Deny_log_on_as_a_service'
	 	{
	 	 	Policy = 'Deny_log_on_as_a_service'
	 	 	Identity = @('ADD YOUR ENTERPRISE ADMINS', 'ADD YOUR DOMAIN ADMINS'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Deny_access_to_this_computer_from_the_network'
	 	{
	 	 	Policy = 'Deny_access_to_this_computer_from_the_network'
	 	 	Identity = @('*S-1-5-113', '*S-1-5-32-546', 'ADD YOUR ENTERPRISE ADMINS', 'ADD YOUR DOMAIN ADMINS'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Enable_computer_and_user_accounts_to_be_trusted_for_delegation'
	 	{
	 	 	Policy = 'Enable_computer_and_user_accounts_to_be_trusted_for_delegation'
	 	 	Identity = @(''
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Force_shutdown_from_a_remote_system'
	 	{
	 	 	Policy = 'Force_shutdown_from_a_remote_system'
	 	 	Identity = @('*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Access_this_computer_from_the_network'
	 	{
	 	 	Policy = 'Access_this_computer_from_the_network'
	 	 	Identity = @('*S-1-5-11', '*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Perform_volume_maintenance_tasks'
	 	{
	 	 	Policy = 'Perform_volume_maintenance_tasks'
	 	 	Identity = @('*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Act_as_part_of_the_operating_system'
	 	{
	 	 	Policy = 'Act_as_part_of_the_operating_system'
	 	 	Identity = @(''
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Generate_security_audits'
	 	{
	 	 	Policy = 'Generate_security_audits'
	 	 	Identity = @('*S-1-5-20', '*S-1-5-19'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Access_Credential_Manager_as_a_trusted_caller'
	 	{
	 	 	Policy = 'Access_Credential_Manager_as_a_trusted_caller'
	 	 	Identity = @(''
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Back_up_files_and_directories'
	 	{
	 	 	Policy = 'Back_up_files_and_directories'
	 	 	Identity = @('*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Manage_auditing_and_security_log'
	 	{
	 	 	Policy = 'Manage_auditing_and_security_log'
	 	 	Identity = @('*S-1-5-32-544'
	 	 	)

	 	}

	 	UserRightsAssignment 'UserRightsAssignment(INF): Bypass_traverse_checking'
	 	{
	 	 	Policy = 'Bypass_traverse_checking'
	 	 	Identity = @('*S-1-5-90-0', '*S-1-5-20', '*S-1-5-19', '*S-1-5-11', '*S-1-5-32-544'
	 	 	)

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\LanmanWorkstation\Parameters\EnablePlainTextPassword'
	 	{
	 	 	ValueName = 'EnablePlainTextPassword'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Services\LanmanWorkstation\Parameters'
	 	 	ValueData = 0

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\FIPSAlgorithmPolicy\Enabled'
	 	{
	 	 	ValueName = 'Enabled'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Lsa\FIPSAlgorithmPolicy'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon\ScRemoveOption'
	 	{
	 	 	ValueName = 'ScRemoveOption'
	 	 	ValueType = 'String'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon'
	 	 	ValueData = '1'

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableInstallerDetection'
	 	{
	 	 	ValueName = 'EnableInstallerDetection'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters\DisablePasswordChange'
	 	{
	 	 	ValueName = 'DisablePasswordChange'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters'
	 	 	ValueData = 0

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon\PasswordExpiryWarning'
	 	{
	 	 	ValueName = 'PasswordExpiryWarning'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon'
	 	 	ValueData = 14

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters\RestrictNullSessAccess'
	 	{
	 	 	ValueName = 'RestrictNullSessAccess'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Session Manager\ProtectionMode'
	 	{
	 	 	ValueName = 'ProtectionMode'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Session Manager'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\LanmanWorkstation\Parameters\RequireSecuritySignature'
	 	{
	 	 	ValueName = 'RequireSecuritySignature'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Services\LanmanWorkstation\Parameters'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters\NullSessionShares'
	 	{
	 	 	ValueName = 'NullSessionShares'
	 	 	ValueType = 'MultiString'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters'
	 	 	ValueData = ''

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableSecureUIAPaths'
	 	{
	 	 	ValueName = 'EnableSecureUIAPaths'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters\SealSecureChannel'
	 	{
	 	 	ValueName = 'SealSecureChannel'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\RestrictAnonymousSAM'
	 	{
	 	 	ValueName = 'RestrictAnonymousSAM'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Lsa'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\PromptOnSecureDesktop'
	 	{
	 	 	ValueName = 'PromptOnSecureDesktop'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\SecurePipeServers\Winreg\AllowedPaths\Machine'
	 	{
	 	 	ValueName = 'Machine'
	 	 	ValueType = 'MultiString'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\SecurePipeServers\Winreg\AllowedPaths'
	 	 	ValueData = @('Software\Microsoft\Windows NT\CurrentVersion\Print Software\Microsoft\Windows NT\CurrentVersion\Windows System\CurrentControlSet\Control\Print\Printers System\CurrentControlSet\Services\Eventlog Software\Microsoft\OLAP Server System\CurrentControlSet\Control\ContentIndex System\CurrentControlSet\Control\Terminal Server System\CurrentControlSet\Control\Terminal Server\UserConfig System\CurrentControlSet\Control\Terminal Server\DefaultUserConfiguration Software\Microsoft\Windows NT\CurrentVersion\Perflib System\CurrentControlSet\Services\SysmonLog'
	 	 	)

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\LanmanWorkstation\Parameters\EnableSecuritySignature'
	 	{
	 	 	ValueName = 'EnableSecuritySignature'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Services\LanmanWorkstation\Parameters'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\ConsentPromptBehaviorUser'
	 	{
	 	 	ValueName = 'ConsentPromptBehaviorUser'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
	 	 	ValueData = 0

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\EveryoneIncludesAnonymous'
	 	{
	 	 	ValueName = 'EveryoneIncludesAnonymous'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Lsa'
	 	 	ValueData = 0

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\DisableDomainCreds'
	 	{
	 	 	ValueName = 'DisableDomainCreds'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Lsa'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\pku2u\AllowOnlineID'
	 	{
	 	 	ValueName = 'AllowOnlineID'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Lsa\pku2u'
	 	 	ValueData = 0

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\LegalNoticeCaption'
	 	{
	 	 	ValueName = 'LegalNoticeCaption'
	 	 	ValueType = 'String'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
	 	 	ValueData = 'US Department of Defense Warning Statement'

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\UseMachineId'
	 	{
	 	 	ValueName = 'UseMachineId'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Lsa'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\RestrictAnonymous'
	 	{
	 	 	ValueName = 'RestrictAnonymous'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Lsa'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0\allownullsessionfallback'
	 	{
	 	 	ValueName = 'allownullsessionfallback'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0'
	 	 	ValueData = 0

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\NoLMHash'
	 	{
	 	 	ValueName = 'NoLMHash'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Lsa'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\LmCompatibilityLevel'
	 	{
	 	 	ValueName = 'LmCompatibilityLevel'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Lsa'
	 	 	ValueData = 5

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters\EnableSecuritySignature'
	 	{
	 	 	ValueName = 'EnableSecuritySignature'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\LegalNoticeText'
	 	{
	 	 	ValueName = 'LegalNoticeText'
	 	 	ValueType = 'MultiString'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
	 	 	ValueData = 'You are accessing a U.S. Government (USG) Information System (IS) that is provided for USG-authorized use only. By using this IS (which includes any device attached to this IS)" " you consent to the following conditions: -The USG routinely intercepts and monitors communications on this IS for purposes including" " but not limited to" " penetration testing" " COMSEC monitoring" " network operations and defense" " personnel misconduct (PM)" " law enforcement (LE)" " and counterintelligence (CI) investigations. -At any time" " the USG may inspect and seize data stored on this IS. -Communications using" " or data stored on" " this IS are not private" " are subject to routine monitoring" " interception" " and search" " and may be disclosed or used for any USG-authorized purpose. -This IS includes security measures (e.g." " authentication and access controls) to protect USG interests--not for your personal benefit or privacy. -Notwithstanding the above" " using this IS does not constitute consent to PM" " LE or CI investigative searching or monitoring of the content of privileged communications" " or work product" " related to personal representation or services by attorneys" " psychotherapists" " or clergy" " and their assistants. Such communications and work product are private and confidential. See User Agreement for details.'

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\DontDisplayLastUserName'
	 	{
	 	 	ValueName = 'DontDisplayLastUserName'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\ValidateAdminCodeSignatures'
	 	{
	 	 	ValueName = 'ValidateAdminCodeSignatures'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
	 	 	ValueData = 0

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0\NTLMMinClientSec'
	 	{
	 	 	ValueName = 'NTLMMinClientSec'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0'
	 	 	ValueData = 537395200

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\SCENoApplyLegacyAuditPolicy'
	 	{
	 	 	ValueName = 'SCENoApplyLegacyAuditPolicy'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Lsa'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\ForceGuest'
	 	{
	 	 	ValueName = 'ForceGuest'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Lsa'
	 	 	ValueData = 0

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\ConsentPromptBehaviorAdmin'
	 	{
	 	 	ValueName = 'ConsentPromptBehaviorAdmin'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
	 	 	ValueData = 4

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\ShutdownWithoutLogon'
	 	{
	 	 	ValueName = 'ShutdownWithoutLogon'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
	 	 	ValueData = 0

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Session Manager\Kernel\ObCaseInsensitive'
	 	{
	 	 	ValueName = 'ObCaseInsensitive'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Session Manager\Kernel'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\InactivityTimeoutSecs'
	 	{
	 	 	ValueName = 'InactivityTimeoutSecs'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
	 	 	ValueData = 900

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters\NullSessionPipes'
	 	{
	 	 	ValueName = 'NullSessionPipes'
	 	 	ValueType = 'MultiString'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters'
	 	 	ValueData = ''

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\Kerberos\Parameters\SupportedEncryptionTypes'
	 	{
	 	 	ValueName = 'SupportedEncryptionTypes'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\Kerberos\Parameters'
	 	 	ValueData = 2147483644

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters\RequireSecuritySignature'
	 	{
	 	 	ValueName = 'RequireSecuritySignature'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters\SmbServerNameHardeningLevel'
	 	{
	 	 	ValueName = 'SmbServerNameHardeningLevel'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters'
	 	 	ValueData = 0

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\DisableCAD'
	 	{
	 	 	ValueName = 'DisableCAD'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
	 	 	ValueData = 0

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters\RequireStrongKey'
	 	{
	 	 	ValueName = 'RequireStrongKey'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters\EnableForcedLogOff'
	 	{
	 	 	ValueName = 'EnableForcedLogOff'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\FullPrivilegeAuditing'
	 	{
	 	 	ValueName = 'FullPrivilegeAuditing'
	 	 	ValueType = 'Binary'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Lsa'
	 	 	ValueData = @(0
	 	 	)

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\LDAP\LDAPClientIntegrity'
	 	{
	 	 	ValueName = 'LDAPClientIntegrity'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Services\LDAP'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters\MaximumPasswordAge'
	 	{
	 	 	ValueName = 'MaximumPasswordAge'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters'
	 	 	ValueData = 30

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableLUA'
	 	{
	 	 	ValueName = 'EnableLUA'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters\AutoDisconnect'
	 	{
	 	 	ValueName = 'AutoDisconnect'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters'
	 	 	ValueData = 15

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableUIADesktopToggle'
	 	{
	 	 	ValueName = 'EnableUIADesktopToggle'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
	 	 	ValueData = 0

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableVirtualization'
	 	{
	 	 	ValueName = 'EnableVirtualization'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\AuditBaseObjects'
	 	{
	 	 	ValueName = 'AuditBaseObjects'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Lsa'
	 	 	ValueData = 0

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters\RequireSignOrSeal'
	 	{
	 	 	ValueName = 'RequireSignOrSeal'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\FilterAdministratorToken'
	 	{
	 	 	ValueName = 'FilterAdministratorToken'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon\AllocateDASD'
	 	{
	 	 	ValueName = 'AllocateDASD'
	 	 	ValueType = 'String'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon'
	 	 	ValueData = '0'

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Session Manager\SubSystems\optional'
	 	{
	 	 	ValueName = 'optional'
	 	 	ValueType = 'MultiString'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Session Manager\SubSystems'
	 	 	ValueData = ''

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\SecurePipeServers\Winreg\AllowedExactPaths\Machine'
	 	{
	 	 	ValueName = 'Machine'
	 	 	ValueType = 'MultiString'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\SecurePipeServers\Winreg\AllowedExactPaths'
	 	 	ValueData = @('System\CurrentControlSet\Control\ProductOptions System\CurrentControlSet\Control\Server Applications Software\Microsoft\Windows NT\CurrentVersion'
	 	 	)

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon\CachedLogonsCount'
	 	{
	 	 	ValueName = 'CachedLogonsCount'
	 	 	ValueType = 'String'
	 	 	Key = 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon'
	 	 	ValueData = '4'

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\LimitBlankPasswordUse'
	 	{
	 	 	ValueName = 'LimitBlankPasswordUse'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Lsa'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Print\Providers\LanMan Print Services\Servers\AddPrinterDrivers'
	 	{
	 	 	ValueName = 'AddPrinterDrivers'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Print\Providers\LanMan Print Services\Servers'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters\SignSecureChannel'
	 	{
	 	 	ValueName = 'SignSecureChannel'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters'
	 	 	ValueData = 1

	 	}

	 	Registry 'Registry(INF): HKLM:\Software\Policies\Microsoft\Cryptography\ForceKeyProtection'
	 	{
	 	 	ValueName = 'ForceKeyProtection'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\Software\Policies\Microsoft\Cryptography'
	 	 	ValueData = 2

	 	}

	 	Registry 'Registry(INF): HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0\NTLMMinServerSec'
	 	{
	 	 	ValueName = 'NTLMMinServerSec'
	 	 	ValueType = 'Dword'
	 	 	Key = 'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0'
	 	 	ValueData = 537395200

	 	}

	 	SecurityOption 'SecuritySetting(INF): NewGuestName'
	 	{
	 	 	Accounts_Rename_guest_account = 'Visitor'
	 	 	Name = 'Accounts_Rename_guest_account'

	 	}

	 	AccountPolicy 'SecuritySetting(INF): PasswordHistorySize'
	 	{
	 	 	Name = 'Enforce_password_history'
	 	 	Enforce_password_history = 24

	 	}

	 	AccountPolicy 'SecuritySetting(INF): MinimumPasswordLength'
	 	{
	 	 	Name = 'Minimum_Password_Length'
	 	 	Minimum_Password_Length = 14

	 	}

	 	AccountPolicy 'SecuritySetting(INF): MinimumPasswordAge'
	 	{
	 	 	Minimum_Password_Age = 1
	 	 	Name = 'Minimum_Password_Age'

	 	}

	 	SecurityOption 'SecuritySetting(INF): ForceLogoffWhenHourExpire'
	 	{
	 	 	Name = 'Network_security_Force_logoff_when_logon_hours_expire'
	 	 	Network_security_Force_logoff_when_logon_hours_expire = 1

	 	}

	 	SecurityOption 'SecuritySetting(INF): LSAAnonymousNameLookup'
	 	{
	 	 	Name = 'Network_access_Allow_anonymous_SID_Name_translation'
	 	 	Network_access_Allow_anonymous_SID_Name_translation = 0

	 	}

	 	AccountPolicy 'SecuritySetting(INF): ResetLockoutCount'
	 	{
	 	 	Reset_account_lockout_counter_after = 15
	 	 	Name = 'Reset_account_lockout_counter_after'

	 	}

	 	AccountPolicy 'SecuritySetting(INF): MaximumPasswordAge'
	 	{
	 	 	Name = 'Maximum_Password_Age'
	 	 	Maximum_Password_Age = 60

	 	}

	 	AccountPolicy 'SecuritySetting(INF): ClearTextPassword'
	 	{
	 	 	Name = 'Store_passwords_using_reversible_encryption'
	 	 	Store_passwords_using_reversible_encryption = 'Disabled'

	 	}

	 	AccountPolicy 'SecuritySetting(INF): LockoutBadCount'
	 	{
	 	 	Name = 'Account_lockout_threshold'
	 	 	Account_lockout_threshold = 3

	 	}

	 	AccountPolicy 'SecuritySetting(INF): LockoutDuration'
	 	{
	 	 	Name = 'Account_lockout_duration'
	 	 	Account_lockout_duration = 15

	 	}

	 	SecurityOption 'SecuritySetting(INF): NewAdministratorName'
	 	{
	 	 	Accounts_Rename_administrator_account = 'X_Admin'
	 	 	Name = 'Accounts_Rename_administrator_account'

	 	}

	 	SecurityOption 'SecuritySetting(INF): EnableGuestAccount'
	 	{
	 	 	Accounts_Guest_account_status = 'Disabled'
	 	 	Name = 'Accounts_Guest_account_status'

	 	}

	 	AccountPolicy 'SecuritySetting(INF): PasswordComplexity'
	 	{
	 	 	Name = 'Password_must_meet_complexity_requirements'
	 	 	Password_must_meet_complexity_requirements = 'Enabled'

	 	}

	 	Service 'Services(INF): SCPolicySvc'
	 	{
	 	 	Name = 'SCPolicySvc'
	 	 	State = 'Running'

	 	}

	}
}